import java.util.Scanner;

public class ArrayExFreq {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Plz enter array size:");
		int n=sc.nextInt();
		int []a=new int[n] ;
		System.out.println("Plz enter "+n+" Array elements:");
		for(int x=0;x<a.length;x++) {
			a[x]=sc.nextInt();
		}
		
		//int a[]= {2,5,9,8,2,6,8,9};
		
		
		for(int x=0;x<a.length;x++) {
			boolean flag=true;
			for(int i=0;i<x;i++) {
				if(a[x]==a[i]) {
					flag=false;
					break;
				}
			}
			if(flag) {
				int count=0;
				for(int y=0;y<a.length;y++) {
					if(a[x]==a[y]) {
						count++;
					}
				}
				System.out.println(a[x]+" occurred "+count+" times");
			}
		}

	}
}
