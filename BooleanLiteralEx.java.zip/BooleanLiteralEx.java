class BooleanLiteralEx{ 
    public static void main(String []s){
        boolean a=true;//Boolean Literal
        boolean b=false;//Boolean Literal
        System.out.println(a);
        System.out.println(b);
    }
} 