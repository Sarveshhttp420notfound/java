
public class StringEx1 {

	public static void main(String[] args) {
		char n[]= {'R','a','h','u','l'};
		System.out.println(n);
		//System.out.println(n.toUpperCase());//error
		System.out.println(n[2]);
		
		String s=new String("Rahul");
		System.out.println(s);
		System.out.println(s.toUpperCase());
		//System.out.println(s[2]);//error
		System.out.println(s.charAt(2));
	}

}
