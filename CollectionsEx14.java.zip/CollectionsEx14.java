import java.util.*;

public class CollectionsEx14 {

	public static void main(String[] args) {
		HashSet a=new HashSet();
		a.add("ram");
		a.add("suresh");
		a.add("rohan");
		a.add("sohan");
		a.add("mohan");
		Iterator i=a.iterator();
		while (i.hasNext()) {
			String b=(String)i.next();
			if(a.contains(b)) {
				i.remove();
			}
		}
		System.out.println(a);
	}

}
