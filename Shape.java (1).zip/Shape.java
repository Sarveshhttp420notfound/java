abstract public class Shape {
	abstract public void findArea();
	abstract public void printArea() ;
}
