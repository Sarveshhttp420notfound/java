package p1;

public class A {
	public int x=10;
	static public int y=20;
	public void m1(){
		System.out.println("Hello A");
	} 
	static public void m2(){
		System.out.println("Hi A");
	}
}
