
public class PrintingExample4 {

	public static void main(String[] args) {
		int a=10,b=5;
		//Values are 10,5
		System.out.println( "Values are "+a+","+b );
		//Value of a=10 and b=5
		System.out.println( "Value of a="+a+" and b="+b );
		//Sum of 10 and 5 is 15.
		System.out.println( "Sum of "+a+" and "+b+" is "+(a+b)+"." );
	}

}
