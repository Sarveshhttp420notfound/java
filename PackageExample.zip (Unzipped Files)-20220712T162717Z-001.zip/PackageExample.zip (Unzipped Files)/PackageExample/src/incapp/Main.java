package incapp;

public class Main {

	public static void main(String[] args) {
		p1.A a=new p1.A();
		//System.out.println(a.x);//error
		a.m1();
		p1.B b=new p1.B();
		System.out.println(b.y);
		b.m2();
		p2.A a2=new p2.A();
		System.out.println(a2.h);
		a2.m();
		p2.D d=new p2.D();
		System.out.println(d.z);
		d.m3();
	}
	
}
