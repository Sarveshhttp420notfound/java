package p1;

public class A {
	int x=10;
	public void m1(){
		System.out.println("Hello A");
	}
}
