package p1;

public class B {
	public int y=20;
	public void m2(){
		System.out.println("Hello B");
		A a=new A();
		System.out.println(a.x);
		a.m1();
	}
}
