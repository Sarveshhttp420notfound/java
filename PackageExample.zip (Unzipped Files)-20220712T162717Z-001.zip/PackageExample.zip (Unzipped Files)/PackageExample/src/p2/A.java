package p2;

public class A {
	public int h=40;
	public void m(){
		System.out.println("Hi A");
	}
}
