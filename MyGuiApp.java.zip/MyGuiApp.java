import javax.swing.*;
import java.awt.*;
class Gui extends JFrame{
	JButton b1,b2;
	JLabel l;
	JTextField t;
	Gui(){
		setTitle("Mera Pehla Frame");
		setSize(400, 300);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		getContentPane().setBackground(Color.YELLOW);
		setLayout(null);
		
		b1=new JButton("OK");
		b1.setBounds(50,40,60,30);
		add(b1);
		b2=new JButton("OK2");
		b2.setBounds(120,40,60,30);
		add(b2);
		
		l=new JLabel("Hello INCAPP");
		l.setBounds(50,80,100,30);
		add(l);
		
		t=new JTextField();
		t.setBounds(50,120,110,30);
		add(t);
		
	}
}
public class MyGuiApp {

	public static void main(String[] args) {
		Gui g=new Gui();
		g.setVisible(true);
	}

}
