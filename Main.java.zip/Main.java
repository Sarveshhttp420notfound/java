package incapp;
import p1.B;
import p1.A;
//import p2.A;//error
import p2.D;
import p1.*;
import p2.*;
public class Main {

	public static void main(String[] args) {
		A a=new A();
		//System.out.println(a.x);//error
		a.m1();
		B b=new B();
		System.out.println(b.y);
		b.m2();
		p2.A a2=new p2.A();
		System.out.println(a2.h);
		a2.m();
		D d=new D();
		System.out.println(d.z);
		d.m3();
	}
	
}
