class IntegerLiteralQues{
    static public void main(String []s){
        int a=05;
        //int b=08;
        int c=010;
        System.out.println(a);
        //System.out.println(b);
        System.out.println(c);
    }
} 