class Demo{
    static public void main(String []s){
        System.out.printf("Hello INCAPP\n");
        int a=10,b=20,r=a+b;
        System.out.println(r);
    }
} 