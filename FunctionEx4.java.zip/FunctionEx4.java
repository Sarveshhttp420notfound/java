
public class FunctionEx4 {
	static int add(int a,int b) {
		int r=a+b;
		return r;
	}
	public static void main(String[] args) {
		int r=add(15,48);
		System.out.println("Sum: "+r);
	}

}
