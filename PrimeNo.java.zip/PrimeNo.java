
public class PrimeNo {
	public static void main(String[] args) {
		java.util.Scanner sc=new java.util. Scanner( System.in );
		
		System.out.println("Enter a no.: ");
		int n=sc.nextInt();
		if(n<=1) {
			System.out.println(n+" is NOT Prime");
		}else {
			boolean flag=true;
			for(int x=2;x<=n-1;x++) {
				if(n%x==0) {
					System.out.println(n+ " is Not Prime");
					flag=false;
					break;
				}
			}
			if(flag) {
				System.out.println(n+" is Prime");
			}
		}
	}
}
