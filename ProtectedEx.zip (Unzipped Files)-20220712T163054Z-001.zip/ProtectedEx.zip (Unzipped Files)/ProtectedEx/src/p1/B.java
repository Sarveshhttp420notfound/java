package p1;

public class B {
	public void m() {
		A a=new A();
		System.out.println(a.x);
	}
}
