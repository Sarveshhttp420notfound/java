package main;

import p1.A;

public class B {
	public void m() {
		A a=new A();
		//System.out.println(a.x);//error
	}
}
