
public class ForLoopEx6 {
	public static void main(String[] args) {
		for(int x=1;x++<=10;x++) { 
			System.out.println(x);
		}
	}
}
