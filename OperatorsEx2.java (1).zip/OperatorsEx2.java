
public class OperatorsEx2 {

	public static void main(String[] args) {
		int a=7/2;
		System.out.println(a);
		a=-7/2;
		System.out.println(a);
		a=7/-2;
		System.out.println(a);
		a=-7/-2;
		System.out.println(a);
		
		a=7%2;
		System.out.println(a);
		a=-7%2;
		System.out.println(a);
		a=7%-2;
		System.out.println(a);
		a=-7%-2;
		System.out.println(a);
	}

}
