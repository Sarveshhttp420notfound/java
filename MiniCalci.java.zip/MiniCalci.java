package minicalci;
import javax.swing.*;
import java.awt.*;
class Gui extends JFrame{
    JPanel p;
    JLabel l1,l2,l3,l4;
    JTextField t1,t2;
    JButton b1,b2,b3,b4,b5;
    Gui(){
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(400,250);
        setTitle("Mini Calci");
        getContentPane().setBackground(Color.DARK_GRAY);
        
        Font font1=new Font(Font.SANS_SERIF, Font.BOLD, 18);
        Font font2=new Font(Font.MONOSPACED, Font.BOLD, 12);
        
        p=new JPanel();
        p.setLayout(null);
        p.setBounds(40,20,300,150);
        p.setBackground(Color.YELLOW);
        add(p);
        
        l1=new JLabel("Enter 1st No:");
        l1.setBounds(20,20,100,20);
        l1.setFont(font2);
        p.add(l1);
        t1=new JTextField();
        t1.setHorizontalAlignment(0);
        t1.setForeground(Color.RED);
        t1.setBounds(130,18,120,27);
        t1.setFont(font2);
        p.add(t1);
        l2=new JLabel("Enter 2nd No:");
        l2.setBounds(20,60,100,20);
        l2.setFont(font2);
        p.add(l2);
        t2=new JTextField();
        t2.setHorizontalAlignment(0);
        t2.setForeground(Color.RED);
        t1.setFont(font2);
        t2.setBounds(130,58,120,27);
        p.add(t2);
        
        b1=new JButton("+");
        b1.setBounds(20,100,50,40);
        b1.setBackground(Color.DARK_GRAY);
        b1.setForeground(Color.WHITE);
        b1.setFont(font1);
        p.add(b1);
        b2=new JButton("-");
        b2.setBounds(75,100,50,40);
        b2.setBackground(Color.DARK_GRAY);
        b2.setForeground(Color.WHITE);
        b2.setFont(font1);
        p.add(b2);
        b3=new JButton("*");
        b3.setBounds(130,100,50,40);
        b3.setBackground(Color.DARK_GRAY);
        b3.setForeground(Color.WHITE);
        b3.setFont(font1);
        p.add(b3);
        b4=new JButton("/");
        b4.setBounds(185,100,50,40);
        b4.setBackground(Color.DARK_GRAY);
        b4.setForeground(Color.WHITE);
        b4.setFont(font1);
        p.add(b4);
        b5=new JButton("%");
        b5.setBounds(240,100,55,40);
        b5.setBackground(Color.DARK_GRAY);
        b5.setForeground(Color.WHITE);
        b5.setFont(font1);
        p.add(b5);
        
        l3=new JLabel("Answer: ");
        l3.setForeground(Color.WHITE);
        l3.setFont(font2);
        l3.setBounds(50,180,80,20);
        add(l3);
        l4=new JLabel("----------------");
        l4.setForeground(Color.WHITE);
        l4.setFont(font2);
        l4.setBounds(140,180,150,20);
        add(l4);
    }
}
public class MiniCalci {

    public static void main(String[] args) {
        Gui g=new Gui();
        g.setVisible(true);
    }
}
