class StringLiteralEx{ 
    public static void main(String []s){
        String a="Rahul Chauhan";//String Literal
        String b="10";//String Literal
        System.out.println(a);
        System.out.println(b);
    }
} 