
public class OperatorsEx4 {

	public static void main(String[] args) {
		int a=12;
		a++;
		System.out.println(a);
		byte b=12;
		b++;
		System.out.println(b);
		short c=12;
		c++;
		System.out.println(c);
		long d=12;
		d++;
		System.out.println(d);
		float e=12.4f;
		e++;
		System.out.println(e);
		double f=12.4;
		f++;
		System.out.println(f);
		char g='h';
		g++;
		System.out.println(g);
	}

}
