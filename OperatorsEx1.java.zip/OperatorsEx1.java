
public class OperatorsEx1 {

	public static void main(String[] args) {
		int a=7/2;
		System.out.println(a);
		double b=7/2;
		System.out.println(b);
		double c=7/2.0;
		System.out.println(c);
	}

}
