 public interface Shape {
	void findArea();
	abstract public void printArea() ;
}
