
public class ClassObjectExample1 {
	public static void main(String[] args) {
		Employee a=new Employee();
		Employee b=new Employee();
		Employee c=new Employee();
		Employee d=new Employee();
		//System.out.println(name);//error
		
		a.name="Yoyo Gupta";
		a.salary=89000;
		a.cname="ABC";
		b.name="Teja Singh";
		b.salary=65000;
		b.cname="XYZ";
		c.name="Cheetah Khan";
		c.salary=783000;
		c.cname="PQR";
		d.name="Lalu Kumar";
		d.salary=21;
		d.cname="JAIL";
		
		System.out.println(a.name+" "+a.salary+" "+a.cname);
		System.out.println(b.name+" "+b.salary+" "+b.cname);
		System.out.println(c.name+" "+c.salary+" "+c.cname);
		System.out.println(d.name+" "+d.salary+" "+d.cname);
	}
}
class Employee{
	String name;
	int salary;
	String cname;
}
