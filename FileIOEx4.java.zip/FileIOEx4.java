import java.io.*;
public class FileIOEx4 {

	public static void main(String[] args) {
		try {
			//Byte Stream
			FileInputStream f=new FileInputStream("D:\\Java Codes\\abc.txt"); 
			int a;
			while((a=f.read()) != -1) {
				System.out.print((char)a);
			}
			f.close();
		}catch (Exception e) {
			System.out.println(e);
		}
	}

}
