
public class ForLoopEx1 {
	public static void main(String[] args) {
		for(int x=1;x<=5;x++) {
			System.out.println("Rahul Chauhan");
		}
		System.out.println("-------");
		for(int x=1;x<=5;++x) {
			System.out.println("Rahul Chauhan");
		}
		System.out.println("-------");
		for(int x=1;x<=5;x=x+1) {
			System.out.println("Rahul Chauhan");
		}
		System.out.println("-------");
		for(int x=1;x<=5;x+=1) {
			System.out.println("Rahul Chauhan");
		}
		System.out.println("-------");
		for(int x=11;x<=15;x++) {
			System.out.println("Rahul Chauhan");
		}
		System.out.println("-------");
		for(int x=5;x>=1;x--) {
			System.out.println("Rahul Chauhan");
		}
	}
}
