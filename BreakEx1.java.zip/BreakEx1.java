
public class BreakEx1 {
	public static void main(String[] args) {
		java.util.Scanner sc=new java.util. Scanner( System.in );
		
		System.out.println("Enter a no.: ");
		int a=sc.nextInt();
		for(int x=1;x<=a;x++) { 
			System.out.println("Hello");
			if(x==3) {
				break;
			}
			System.out.println("Rahul Chauhan");
		}
	}
}
