
public class A {
	void show() {
		System.out.println("Hello A");
	}
}
