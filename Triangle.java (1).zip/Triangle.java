public class Triangle extends Shape {
	private double a;

	public void findArea() {
		a = 8.1*6.4/2;
	}

	public void printArea() {
		System.out.println("Triangle's Area: " + a);
	}

}
