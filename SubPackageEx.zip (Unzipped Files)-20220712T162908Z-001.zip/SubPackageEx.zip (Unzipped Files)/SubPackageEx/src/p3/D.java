package p3;

import p1.p2.*;
import p1.*;
public class D {
	public void m() {
		B b=new B();
		System.out.println(b.y);
		A a=new A();
		G g=new G();
	}
}
