package p1;

public class G {

}
