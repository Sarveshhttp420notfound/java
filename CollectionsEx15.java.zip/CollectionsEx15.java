import java.util.*;

public class CollectionsEx15 {

	public static void main(String[] args) {
		int a[]= {2,8,4,5,2,1,5,1,5,245,5,5,7};
		Arrays.sort(a);
		for (int i : a) {
			System.out.print(i+" ");
		}
		System.out.println();
		
		LinkedHashSet<Integer> b=new LinkedHashSet();
		for (int i : a) {
			b.add(i);
		}
		System.out.println(b);
	}

}
