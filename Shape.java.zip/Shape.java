public class Shape {
	public void findArea() {
		
	}
	public void printArea() {
		
	}
}
