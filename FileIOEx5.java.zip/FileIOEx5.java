import java.io.*;
public class FileIOEx5 {

	public static void main(String[] args) {
		try {
			//Character Stream
			FileReader f=new FileReader("D:\\Java Codes\\abc.txt"); 
			int a;
			while((a=f.read()) != -1) {
				System.out.print((char)a);
			}
			f.close();
		}catch (Exception e) {
			System.out.println(e);
		}
	}

}
