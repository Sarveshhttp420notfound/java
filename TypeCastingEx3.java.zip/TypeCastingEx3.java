class TypeCastingEx3{ 
    public static void main(String []s){
        System.out.println(2147483647);
        System.out.println(2147483647545L);
        System.out.println(6.3);
    }
} 