class IntegerLiteralEx{
    static public void main(String []s){
        int a=104;//Decimal Integer Literal
        int b=0150;//Octal Integer Literal
        int c=0b1101000;//Binary Integer Literal
        //int c=0B1101000;//Allowed
        int d=0x68;//Hexa-Decimal Integer Literal
        //int d=0X68;//Allowed
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
    }
} 