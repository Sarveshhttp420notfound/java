class FloatingPointLiteralEx{
    static public void main(String []s){
        double a=256.7842;//Normal Floating-Point Literal
        double b=2.567842e+2;//Exponential Floating-Point Literal
        System.out.println(a);
        System.out.println(b);

        double x=2_56.7_842;
        //double x=2_56_._7_842;//error
        //double x=_2_56.7_842_;//error
        System.out.println(x);
    }
} 